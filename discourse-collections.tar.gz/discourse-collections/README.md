# Discourse Collections

This plugin adds support for topic and category collections in Discourse.

- Create curated collections of topics or categories.
- Display collections in the sidebar.
- Admin interface for assigning collections to categories.
